from flask import Flask, render_template, request, flash, redirect, url_for
from wtforms import Form, StringField, SubmitField, validators, PasswordField, BooleanField
from flask_wtf import Form

app = Flask(__name__)
app.config['SECRET_KEY'] = 'f31e4407a7bc58092ea94247168e6a7a'


# Sunnybright
@app.route('/')
def sunnybright():
	return render_template('sunnybright.html')

@app.route('/sunnybright_earrings', methods=['GET', 'POST'])
def sunnybright_earrings():
	if request.method == 'POST':
		return redirect(url_for('sunnybright'))
	return render_template('sunnybright_earrings.html')

@app.route('/sunnybright_earcuffs', methods=['GET', 'POST'])
def sunnybright_earcuffs():
	if request.method == 'POST':
		return redirect(url_for('sunnybright'))
	return render_template('sunnybright_earcuffs.html')

@app.route('/sunnybright_necklace', methods=['GET', 'POST'])
def sunnybright_necklace():
	if request.method == 'POST':
		return redirect(url_for('sunnybright'))
	return render_template('sunnybright_necklace.html')	

@app.route('/sunnybright_bracelet', methods=['GET', 'POST'])
def sunnybright_bracelet():
	if request.method == 'POST':
		return redirect(url_for('sunnybright'))
	return render_template('sunnybright_bracelet.html')	

@app.route('/sunnybright_rings', methods=['GET', 'POST'])
def sunnybright_rings():
	if request.method == 'POST':
		return redirect(url_for('sunnybright'))
	return render_template('sunnybright_rings.html')	

@app.route('/sunnybright_brooches', methods=['GET', 'POST'])
def sunnybright_brooches():
	if request.method == 'POST':
		return redirect(url_for('sunnybright'))
	return render_template('sunnybright_brooches.html')	

@app.route('/sunnybright_luckydraw', methods=['GET', 'POST'])
def sunnybright_luckydraw():
	if request.method == 'POST':
		return redirect(url_for('sunnybright'))
	return render_template('sunnybright_luckydraw.html')

@app.route('/sunnybright_luckydrawpresent', methods=['GET', 'POST'])
def sunnybright_luckydrawpresent():
	if request.method == 'POST':
		return redirect(url_for('sunnybright'))
	return render_template('sunnybright_luckydrawpresent.html')	

class RegistrationForm(Form):
    name = StringField('Name', [validators.Length(min=1, max=50)])
    username = StringField('Username', [validators.Length(min=4, max=25)])
    email = StringField('Email', [validators.Length(min=6, max=50)])
    password = PasswordField('Password', [
        validators.DataRequired(),
    ])
    confirm_password = PasswordField('Confirm Password')
    

class LoginForm(Form):
    email = StringField('Email', [validators.Length(min=6, max=50)])
    password = PasswordField('Password', [
        validators.DataRequired(),
        validators.EqualTo('confirm', message='Passwords do not match')
    ])
    remember = BooleanField('Remember Me')


# User Register
@app.route('/sunnybright_register',methods=['GET','POST'])
def sunnybright_register():
    form = RegistrationForm()
    if form.validate_on_submit():
    	flash(f'Account created for {form.username.data}!', 'success')
    	return redirect(url_for('sunnybright_login'))
    return render_template('sunnybright_register.html', form=form)

# User Login
@app.route('/sunnybright_login', methods=['GET', 'POST'])
def sunnybright_login():
	form = LoginForm()
	if form.validate_on_submit():
		if form.email.data == 'admin@login.com' and form.password.data == 'password':
			flash('You have been logged in!', 'success')
			return redirect(url_for('sunnybright'))
		else:
			flash('Login Unsuccessful. Please check email and password', 'danger')
	return render_template('sunnybright_login.html', form=form)


if __name__ == '__main__':
	app.run(debug = True)
	app.run(host="0.0.0.0", port=8000)

